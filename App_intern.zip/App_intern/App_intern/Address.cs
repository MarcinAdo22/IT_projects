﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace App_intern
{
    internal class Address
    {
        private string postcode;
        private string city_name;
        private int nr_home;
        private string street_name;

        public string Postcode { get { return postcode; } set { postcode = value; } }
        public string CityName { get { return city_name; } set { city_name = value; } }

        public int Nr_home { get { return nr_home; } set { nr_home = value; } }

        public string Streetname { get { return street_name; } set { street_name = value; } }

        public Address() {

            this.postcode = "00-000";
            this.city_name = "city_name";
            this.nr_home = 0;
            this.street_name = "street_name";
        
        }

        public Address(string kod_pocztowy, string miasto_nazwa, int nr_domu, string ulica_nazwa)
        {
            this.postcode=kod_pocztowy;
            this.city_name=miasto_nazwa;
            this.nr_home=nr_domu;
            this.street_name=ulica_nazwa;
        }

        public void getAddressData()
        {
            Console.WriteLine("Address data for this person: \n");
            
            Console.WriteLine("Postcode: " + this.postcode);
            Console.WriteLine("City_name: " + this.city_name);
            Console.WriteLine("Nr_home: " + this.nr_home);
            Console.WriteLine("Street_name: " + this.street_name);
        }

        public Address updateAddressData(string column_name)
        {
            int wart_upd = 20;

            do
            {
                if (column_name == "P")
                {
                    Console.Write("Enter postcode to modify: ");

                    string str = Console.ReadLine();

                    this.postcode = str;

                    wart_upd = 37;
                }
                else if (column_name == "C")
                {
                    Console.Write("Enter city_name to modify: ");

                    string city_name_nas = Console.ReadLine();

                    this.city_name = city_name_nas;

                    wart_upd = 37;
                }
                else if (column_name == "N")
                {
                    Console.Write("Enter nr_home to modify: ");

                    int nr_home_val = int.Parse(Console.ReadLine());

                    this.nr_home = nr_home_val;

                    wart_upd = 37;
                }
                else if (column_name == "S")
                {
                    Console.Write("Enter street_name to modify: ");

                    string street_wart = Console.ReadLine();

                    this.street_name = street_wart;

                    wart_upd = 37;
                }
                else
                {
                    Console.Write("Please, you can choose only these options: P - update postcode, C - update city_name, N - update nr_home, S - update street_name :): ");

                    column_name = Console.ReadLine();
                }


            } while (wart_upd <= 20);



            return new Address { Postcode = this.postcode, CityName = this.city_name, Nr_home = this.nr_home, Streetname = this.street_name };
        }

        public Address addAddressData()
        {
            string postcode_nas;
            string city_name_nas;
            int nr_home_nas;
            string street_name_nas;
            
            Console.Write("Enter your postcode_nas: ");
            postcode_nas = Console.ReadLine();
            Console.Write("Enter your city_name_nas: ");
            city_name_nas = Console.ReadLine();
            Console.Write("Enter your nr_home_nas: ");
            nr_home_nas = int.Parse(Console.ReadLine());
            Console.Write("Enter your street_name_nas: ");
            street_name_nas = Console.ReadLine();


            return new Address { Postcode = postcode_nas, CityName = city_name_nas, Nr_home = nr_home_nas, Streetname = street_name_nas };



        }

    }
}
