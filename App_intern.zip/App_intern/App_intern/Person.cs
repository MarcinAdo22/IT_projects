﻿using System;

namespace App_intern
{
    internal class Person
    {
        private string name;
        private string lastname;
        private int age;
        private string pesel;
        private Address address_os = new Address();

        public string Name { get { return name; } set { name = value; } }

        public string Lastname { get { return lastname; } set { lastname = value; } }

        public int Age { get { return age; } set { age = value; } }

        public string PESEL { get { return pesel; } set { pesel = value; } }

        public Address Address_os { get { return address_os; } set { address_os = value; } }

        public Person()
        {
            this.name = "Name";
            this.lastname = "lastname";
            this.age = 0;
            this.pesel = "00011122233";

        }

        public Person(string name_os, string lastname_os, int wiek_os, string pesel_os)
        {
            this.name = name_os;
            this.lastname = lastname_os;
            this.age = wiek_os;
            this.pesel = pesel_os;

        }

        public void getPersonData()
        {
            Console.WriteLine("Data for person: \n");
            Console.WriteLine("");
            Console.WriteLine("Imie: " + this.name);
            Console.WriteLine("Nazwisko: " + this.lastname);
            Console.WriteLine("Wiek: " + this.age.ToString());
            Console.WriteLine("Nr_PESEL: " + this.pesel);

            this.address_os.getAddressData();
        }

        public Person updatePersonData(string column_name)
        {
            int wart = 0;
            int wart_nas = 7;

            do
            {

                if (column_name == "N")
                {
                    Console.Write("Enter and modify name for this person: ");
                    string upd_Name = Console.ReadLine();
                    this.name = upd_Name;
                    wart_nas = 14;
                }
                else if (column_name == "L")
                {
                    Console.Write("Enter and modify lastname for this person: ");
                    string upd_Lastname = Console.ReadLine();
                    this.lastname = upd_Lastname;
                    wart_nas = 14;
                }

                else if (column_name == "W")
                {
                    Console.Write("Enter and modify age for this person: ");
                    int upd_wiek = int.Parse(Console.ReadLine());
                    this.age = upd_wiek;
                    wart_nas = 14;
                }

                else if (column_name == "P")
                {
                    Console.Write("Enter and modify pesel for this person: ");
                    string upd_pesel = Console.ReadLine();
                    while (upd_pesel.Length != 11)
                    {
                        Console.Write("Sorry, but PESEL has exactly 11 characters :/ Please enter rightly PESEL to modify one more time !: ");
                        upd_pesel = Console.ReadLine();
                    }

                    this.pesel = upd_pesel;
                    wart_nas = 14;
                }

                else
                {
                    Console.Write("Please, enter one from these options to modify data for this person: N - update Name, L - update Lastname, W - update Age, P - update PESEL :): ");
                    column_name = Console.ReadLine();

                }

                if (wart_nas == 14)
                {
                    Console.Write("Do you want to modify other data for this person: 0 - Yes, I do :), Other number - No, thanks :): ");
                    wart = int.Parse(Console.ReadLine());

                    if (wart == 0) {
                        
                        Console.Write("Please, enter one from these options to modify data for this person: N - update Name, L - update Lastname, W - update Age, P - update PESEL :): ");
                        column_name = Console.ReadLine();
                        wart_nas = 16;
                    }
                }




            }
            while (wart == 0);


            return new Person { Name = this.name, Lastname = this.lastname, Age = this.age, PESEL = this.pesel };

        }

        public Person addPersonData()
        {
            string name_os;
            string lastname_os;
            int age_os;
            string pesel_os;
            Address address_nas = new Address();

            Console.Write("Enter your name: ");
            name_os = Console.ReadLine();
            Console.Write("Enter your lastname: ");
            lastname_os = Console.ReadLine();
            Console.Write("Enter your age: ");
            age_os = int.Parse(Console.ReadLine());
            Console.Write("Enter your pesel: ");
            pesel_os = Console.ReadLine();

            while (pesel_os.Length > 11)
            {
                Console.Write("Please set your pesel with 11 digits: ");
                pesel_os = Console.ReadLine();

            }

            address_nas = address_nas.addAddressData();

            Console.WriteLine("");



            return new Person { Name = name_os, Lastname = lastname_os, Age = age_os, PESEL = pesel_os, Address_os = address_nas };

        }
    }

}

