﻿using System;
using System.IO.Pipes;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

namespace App_intern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string column_name_os;

            List<Person> list_person = new List<Person>();

            Person osoba_0 = new Person();

            osoba_0.getPersonData();

            Person osoba_1 = new Person("Natalia", "Urocza", 23, "12345685867");

            osoba_1.getPersonData();

            Console.WriteLine("");
            Console.Write("Enter column name you want to update: N - Name, L - Lastname, W - Age, P - PESEL :): ");

            column_name_os = Console.ReadLine();

            Person osoba_2 = osoba_1.updatePersonData(column_name_os);

            Console.WriteLine("");
            Console.WriteLine("Updating data for osoba_1... :)");

            osoba_2.getPersonData();

            Console.Write("Enter your size of list_person: ");
            
            int list_size = int.Parse(Console.ReadLine());

            Person osoba_3;

            
            for (int s = 0; s < list_size; s++)
            {
                osoba_3 = osoba_2.addPersonData();

                list_person.Add(osoba_3);
            }

            foreach (Person osoba in list_person)
            {
                Console.WriteLine("Osoba: " + list_person.IndexOf(osoba) + "\n");
                
                Console.WriteLine("Imie: " + osoba.Name);
                Console.WriteLine("Nazwisko: " + osoba.Lastname);
                Console.WriteLine("Wiek: " + osoba.Age);
                Console.WriteLine("PESEL: " + osoba.PESEL);
                Console.WriteLine("");
                Console.WriteLine("Kod_pocztowy: " + osoba.Address_os.Postcode);
                Console.WriteLine("Miasto: " + osoba.Address_os.CityName);
                Console.WriteLine("Nr_domu: " + osoba.Address_os.Nr_home);
                Console.WriteLine("Ulica: " + osoba.Address_os.Streetname);
                Console.WriteLine("");



            }


            

            
            Query query_nas = new Query();

            query_nas.Query_where_str_column(list_person);




        }
    }
}