﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App_intern
{
    internal class Query
    {
        IEnumerable<Person> query;

        public Query() { 

            query = new List<Person>();
        }

        public void Query_where_str_column(List<Person> osoba_list)
        {
            
            int s = 0;
            int column_wart = 0;
            string threshold_val = "";

            Console.Write("Please, choose one of options for where clausule: 1 - '==', 2 - '!=', 3 - '.Contains()', 4 - '!.Contains()': ");
            s = int.Parse(Console.ReadLine());
            Console.Write("Please, select column to where clausule: 1 - Name, 2 - Lastname, 3 - PESEL: ");
            column_wart = int.Parse(Console.ReadLine());
            Console.Write("Please, enter your threshold value: ");
            threshold_val = Console.ReadLine();

            if (s == 1)
            {
                if (column_wart == 1)
                {
                    this.query = from osoba_nas in osoba_list
                                 where osoba_nas.Name == threshold_val
                                 select osoba_nas;

                }
                else if(column_wart == 2)
                {
                    this.query = from osoba_nas in osoba_list
                                 where osoba_nas.Lastname == threshold_val
                                 select osoba_nas;
                }
                else
                {
                    this.query = from osoba_nas in osoba_list
                                 where osoba_nas.PESEL == threshold_val
                                 select osoba_nas;
                }

                foreach (var os_from_list in this.query)
                {
                    Console.WriteLine("Osoba nr: " + osoba_list.IndexOf(os_from_list));
                    Console.WriteLine("");

                    Console.WriteLine("Imie: " + os_from_list.Name);
                    Console.WriteLine("Nazwisko: " + os_from_list.Lastname);
                    Console.WriteLine("Wiek: " + os_from_list.Age);
                    Console.WriteLine("PESEL: " + os_from_list.PESEL);

                    Console.WriteLine("");
                }



            }
            else if (s == 2)
            {
                if (column_wart == 1)
                {
                    this.query = from osoba_nas in osoba_list
                                 where osoba_nas.Name != threshold_val
                                 select osoba_nas;

                }
                else if (column_wart == 2)
                {
                    this.query = from osoba_nas in osoba_list
                                 where osoba_nas.Lastname != threshold_val
                                 select osoba_nas;
                }
                else
                {
                    this.query = from osoba_nas in osoba_list
                                 where osoba_nas.PESEL != threshold_val
                                 select osoba_nas;
                }

                foreach (var os_from_list in this.query)
                {
                    Console.WriteLine("Osoba nr: " + osoba_list.IndexOf(os_from_list));
                    Console.WriteLine("");

                    Console.WriteLine("Imie: " + os_from_list.Name);
                    Console.WriteLine("Nazwisko: " + os_from_list.Lastname);
                    Console.WriteLine("Wiek: " + os_from_list.Age);
                    Console.WriteLine("PESEL: " + os_from_list.PESEL);

                    Console.WriteLine("");
                }


            }
            else if (s == 3)
            {
                if (column_wart == 1)
                {
                    this.query = from osoba_nas in osoba_list
                                 where osoba_nas.Name.Contains(threshold_val)
                                 select osoba_nas;

                }
                else if (column_wart == 2)
                {
                    this.query = from osoba_nas in osoba_list
                                 where osoba_nas.Lastname.Contains(threshold_val)
                                 select osoba_nas;
                }
                else
                {
                    this.query = from osoba_nas in osoba_list
                                 where osoba_nas.PESEL.Contains(threshold_val)
                                 select osoba_nas;
                }

                foreach (var os_from_list in this.query)
                {
                    Console.WriteLine("Osoba nr: " + osoba_list.IndexOf(os_from_list));
                    Console.WriteLine("");

                    Console.WriteLine("Imie: " + os_from_list.Name);
                    Console.WriteLine("Nazwisko: " + os_from_list.Lastname);
                    Console.WriteLine("Wiek: " + os_from_list.Age);
                    Console.WriteLine("PESEL: " + os_from_list.PESEL);

                    Console.WriteLine("");
                }


            }
            else
            {
                if (column_wart == 1)
                {
                    this.query = from osoba_nas in osoba_list
                                 where !(osoba_nas.Name.Contains(threshold_val))
                                 select osoba_nas;

                }
                else if (column_wart == 2)
                {
                    this.query = from osoba_nas in osoba_list
                                 where !(osoba_nas.Name.Contains(threshold_val))
                                 select osoba_nas;
                }
                else
                {
                    this.query = from osoba_nas in osoba_list
                                 where !(osoba_nas.Name.Contains(threshold_val))
                                 select osoba_nas;
                }

                foreach (var os_from_list in this.query)
                {
                    Console.WriteLine("Osoba nr: " + osoba_list.IndexOf(os_from_list));
                    Console.WriteLine("");

                    Console.WriteLine("Imie: " + os_from_list.Name);
                    Console.WriteLine("Nazwisko: " + os_from_list.Lastname);
                    Console.WriteLine("Wiek: " + os_from_list.Age);
                    Console.WriteLine("PESEL: " + os_from_list.PESEL);

                    Console.WriteLine("");
                }


            }



        }

        public void Query_where_int_column(List<Person> osoba_collection)
        {
            int op = 0;
            int threshold_wart = 0;

            Console.Write("Please, choose one from options for where clausule: 1 - '>', 2 - '<', 3 - '>=', 4 - '<=': ");
            op = int.Parse(Console.ReadLine());
            Console.Write("Please, enter your threshold value for age column: ");
            threshold_wart = int.Parse(Console.ReadLine());

            if (op == 1)
            {
                this.query = from osoba_nas in osoba_collection
                             where osoba_nas.Age > threshold_wart
                             select osoba_nas;
            }
            else if (op == 2)
            {
                this.query = from osoba_nas in osoba_collection
                             where osoba_nas.Age < threshold_wart
                             select osoba_nas;
            }
            else if (op == 3)
            {
                this.query = from osoba_nas in osoba_collection
                             where osoba_nas.Age >= threshold_wart
                             select osoba_nas;
            }
            else
            {
                this.query = from osoba_nas in osoba_collection
                             where osoba_nas.Age <= threshold_wart
                             select osoba_nas;
            }

            foreach (var os_val in this.query)
            {
                Console.WriteLine("Osoba nr: " + osoba_collection.IndexOf(os_val));
                Console.WriteLine("");

                Console.WriteLine("Imie: " + os_val.Name);
                Console.WriteLine("Nazwisko: " + os_val.Lastname);
                Console.WriteLine("Wiek: " + os_val.Age);
                Console.WriteLine("PESEL: " + os_val.PESEL);

                Console.WriteLine("");
            }
        }
        


    }



}


    

